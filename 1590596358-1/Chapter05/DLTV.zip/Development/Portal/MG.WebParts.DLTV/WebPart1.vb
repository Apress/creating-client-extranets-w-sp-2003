'*******************************************************************
' TREEVIEW WEB PART (DLTV)
' Author:   Mark Gerow
' Date:     8/12/05
'*******************************************************************
' Purpose:  Provide a treeview for a document library
'
'*******************************************************************
' Assumes:  Windows SharePoint Services is installed and running
'*******************************************************************
' Notes:
'*******************************************************************
' Mods:     8/13/05: M.Gerow
'           Initial release.
'*******************************************************************
'===================================================================

Imports System
Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Xml.Serialization
Imports Microsoft.SharePoint
Imports Microsoft.SharePoint.Utilities
Imports Microsoft.SharePoint.WebPartPages

'*******************************************************************
' Purpose:      Defines DLTV the TreeView web part.
'*******************************************************************
' Properties:   Doclibname:     the name of the document library to display
'               NodeFormat:     what data to display for each folder/file
'               FolderLocation: whether to display folders before or after
'                               files in tree
'               Order:          sort order for files (Name,Title, or Sequence)
'               IncludeFiles:   show files, or only folders
'               MaxLinkWidth:   Maximum # of chars to include in link
'*******************************************************************
<DefaultProperty("DoclibName"), ToolboxData("<{0}:WebPart1 runat=server></{0}:WebPart1>"), XmlRoot(Namespace:="MG.WebParts.DLTV")> _
Public Class WebPart1
    Inherits Microsoft.SharePoint.WebPartPages.WebPart

    ' This constant is used to delimit text and ordinal position of files in a folder.
    ' A known problem can occur if this delimit character appears in a file name, so
    ' you may need to change if user's typically will give a document a name using 
    ' the provided CONST_SPLITCHAR character.  NOTE: that this is a character not allowed
    ' by SharePoint for folder or file names.
    Private Const CONST_SPLITCHAR = "~"

    ' This constant will be used to  replace any instances of CONST_SPLITCHAR in
    ' a file's name or title for display purposes.
    Private Const CONST_REPLCHAR = "^"

    Private Const _defaultText As String = ""
    Private _docLibName As String = _defaultText
    Private _nodeId As Integer = 0
    Private _includeFiles As Boolean = True
    Private _orderByField As EnumSortField = EnumSortField.Name
    Private _maxLinkWidth As Integer = 50
    Private _folderLocation As EnumFolderLocation = EnumFolderLocation.Bottom
    Private _nodeFormat As EnumNodeFormat = EnumNodeFormat.NameTitle
    Private _useLines As Boolean = True
    Private _daysBack2Include As Integer = 365 * 10 'Default to last 10 years
    Private _showFolders As Boolean = True
    Private _treeViewId As String

#Region "Enumerations"

    Public Enum EnumNodeFormat As Integer
        NameTitle = 1
        TitleName = 2
        Name = 3
        Title = 4
        NameDate = 5
        TitleDate = 6
    End Enum

    Public Enum EnumSortField As Integer
        Name = 1
        Title = 2
        Sequence = 3
    End Enum

    Public Enum EnumFolderLocation As Integer
        Bottom = 0
        Top = 1
    End Enum

#End Region

#Region "Properties"

    ' Comma-delimited list of document libraries to display in DLTV
    <Browsable(True), Category("DLTV TreeView"), DefaultValue(_defaultText), WebPartStorage(Storage.Personal), FriendlyName("Document library name"), Description("Name of document library to display treeview of")> _
    Property [DoclibName]() As String
        Get
            Return _docLibName
        End Get

        Set(ByVal Value As String)
            _docLibName = Value
        End Set
    End Property

    ' Should files be displayed, or only folders
    <Browsable(True), Category("DLTV TreeView"), DefaultValue(True), WebPartStorage(Storage.Personal), FriendlyName("Include files?"), Description("Should files be included in treeview")> _
    Property IncludeFiles() As Boolean
        Get
            Return _includeFiles
        End Get

        Set(ByVal Value As Boolean)
            _includeFiles = Value
        End Set
    End Property

    ' Show folder structure, or only a list of files
    <Browsable(True), Category("DLTV TreeView"), DefaultValue(True), WebPartStorage(Storage.Personal), FriendlyName("Show folders?"), Description("Should folders been shown")> _
     Property ShowFolders() As Boolean
        Get
            Return _showFolders
        End Get

        Set(ByVal Value As Boolean)
            _showFolders = Value
        End Set
    End Property

    ' Display folders at top (as in Windows Explorer) or bottom (as in native SharePoint)
    <Browsable(True), Category("DLTV TreeView"), DefaultValue(EnumFolderLocation.Bottom), WebPartStorage(Storage.Personal), FriendlyName("Folder location"), Description("Should folders be displayed before or after files")> _
    Property FolderLocation() As EnumFolderLocation
        Get
            Return _folderLocation
        End Get

        Set(ByVal Value As EnumFolderLocation)
            _folderLocation = Value
        End Set
    End Property

    ' Select the field to sort file by
    <Browsable(True), Category("DLTV TreeView"), DefaultValue(EnumSortField.Name), WebPartStorage(Storage.Personal), FriendlyName("Order"), Description("What library field should be used to determine order")> _
    Property Order() As EnumSortField
        Get
            Return _orderByField
        End Get

        Set(ByVal Value As EnumSortField)
            _orderByField = Value
        End Set
    End Property

    ' Select the file properties to display in tree
    <Browsable(True), Category("DLTV TreeView"), DefaultValue(EnumNodeFormat.NameTitle), WebPartStorage(Storage.Personal), FriendlyName("Format"), Description("Format to use to display tree nodes")> _
     Property NodeFormat() As EnumNodeFormat
        Get
            Return _nodeFormat
        End Get

        Set(ByVal Value As EnumNodeFormat)
            _nodeFormat = Value
        End Set
    End Property

    ' Set the maximum characters to display for a link
    <Browsable(True), Category("DLTV TreeView"), DefaultValue("50"), WebPartStorage(Storage.Personal), FriendlyName("Max link width"), Description("Length beyond which link text will be truncated")> _
     Property MaxLinkWidth() As String
        Get
            Return _maxLinkWidth
        End Get

        Set(ByVal Value As String)
            _maxLinkWidth = Value
        End Set
    End Property

    ' Should lines between nodes be displayed?
    <Browsable(True), Category("DLTV TreeView"), DefaultValue(True), WebPartStorage(Storage.Personal), FriendlyName("Use lines?"), Description("Use lines in tree")> _
     Property UseLines() As Boolean
        Get
            Return _useLines
        End Get

        Set(ByVal Value As Boolean)
            _useLines = Value
        End Set
    End Property

    ' What's the oldest file to display?
    <Browsable(True), Category("DLTV TreeView"), DefaultValue(360 * 10), WebPartStorage(Storage.Personal), FriendlyName("Include files modified on or before today - # of days"), Description("Include files modified on or after current date-<this value>")> _
     Property DaysBack2Include() As Integer
        Get
            Return _daysBack2Include
        End Get

        Set(ByVal Value As Integer)
            _daysBack2Include = Value
        End Set
    End Property

#End Region

#Region "Primary Methods"

    '*******************************************************************
    ' Purpose:  Render the output of the web part.
    '*******************************************************************
    ' Notes:    Overrides the standard RenderWebPart method.
    '*******************************************************************
    ' Mods:     8/12/05: M.Gerow
    '           Initial production release.
    '
    '*******************************************************************
    Protected Overrides Sub RenderWebPart(ByVal output As System.Web.UI.HtmlTextWriter)

        'No document library to display
        If _docLibName = "" Then
            output.Write("Please enter a document library name")
            Exit Sub
        End If

        Dim site As SPWeb = Microsoft.SharePoint.WebControls.SPControl.GetContextWeb(Context)
        Dim dlCollection As Microsoft.SharePoint.SPListCollection
        Dim arrFlSorted() As String
        Dim dl As Microsoft.SharePoint.SPList
        Dim li As Microsoft.SharePoint.SPListItem
        Dim flCollection As Microsoft.SharePoint.SPFolderCollection
        Dim fl As Microsoft.SharePoint.SPFolder
        Dim fi As Microsoft.SharePoint.SPFile
        Dim lvl As Integer = 0
        Dim thisNodeId As Integer = IncrNodeId()
        Dim parentNodeId As Integer = thisNodeId
        Dim i As Integer
        Dim j As Integer
        Dim colOutput As New Collection

        'Set unique id for this treeview
        _treeViewId = Me.ClientID

        dlCollection = site.Lists

        'Include the Javascript program to display the tree, initialize the tree object
        output.Write("<link rel='StyleSheet' href='_layouts/jtree/dtree.css' type='text/css' />")
        output.Write("<script type='text/javascript' src='_layouts/jtree/dtree.js'></script>")
        output.Write("<script type='text/javascript'>")
        output.Write("d" & _treeViewId.ToString & " = new dTree('d" & _treeViewId.ToString & "');")

        'Set the Javascript properties for the treeview
        SetTreeProperties(output)

        output.Write("d" & _treeViewId.ToString & ".add(" & thisNodeId & ",-1,'','','','','_layouts/images/empty.gif','_layouts/images/empty.gif');")

        For Each dl In dlCollection

            Try
                'Process the desired list
                If IsInDoclibList(dl.Title, [DoclibName]) And dl.BaseType = SPBaseType.DocumentLibrary Then

                    'Display a doclib-level folder if we are including documents from multiple libraries
                    'and folder display is turned on.
                    If _showFolders And IsMultipleDocs([DoclibName]) Then
                        thisNodeId = IncrNodeId()
                        output.Write("d" & _treeViewId.ToString & ".add(" & thisNodeId & "," & parentNodeId & ",'" & dl.Title.Trim & "','" & GetDoclibDefaultViewUrl(dl) & "','','_self','" & dl.ImageUrl & "','" & dl.ImageUrl & "');")
                    End If

                    If _folderLocation = EnumFolderLocation.Bottom Then

                        'Write out the top-level files in the doclib first
                        If _includeFiles Then
                            Try
                                ShowSortedFiles(site.GetFolder(dl.Title.Trim), thisNodeId, output, colOutput)
                            Catch ex0 As Exception
                            End Try
                        End If
                        'Write the folders second
                        Try
                            flCollection = site.GetFolder(dl.Title.Trim).SubFolders
                            ShowSortedFolders(flCollection, 1, thisNodeId, output, colOutput)
                        Catch ex As Exception
                            output.Write("<br>" & ex.Message)
                        End Try

                    Else

                        'Write out the top-level files in the doclib second
                        'Write the folders first
                        Try
                            flCollection = site.GetFolder(dl.Title.Trim).SubFolders
                            ShowSortedFolders(flCollection, 1, thisNodeId, output, colOutput)
                        Catch ex As Exception
                            output.Write("<br>" & ex.Message)
                        End Try
                        If _includeFiles Then
                            Try
                                ShowSortedFiles(site.GetFolder(dl.Title.Trim), thisNodeId, output, colOutput)
                            Catch ex0 As Exception
                            End Try
                        End If

                    End If

                End If

            Catch ex As Exception

            End Try
        Next

        'If NOT showing folders, the files were written to an array, not to the output, 
        'sort the array and write them now.
        If Not _showFolders Then
            Dim arrSortValue(colOutput.Count - 1) As String
            For i = 1 To colOutput.Count
                arrSortValue(i - 1) = CType(colOutput.Item(i), String).Split(CONST_SPLITCHAR)(0) & CONST_SPLITCHAR & CType(colOutput.Item(i), String).Split(CONST_SPLITCHAR)(1)
            Next
            Array.Sort(arrSortValue)
            For i = 0 To arrSortValue.Length - 1
                j = arrSortValue(i).Split(CONST_SPLITCHAR)(1)
                output.Write(CType(colOutput.Item(j + 1), String).Split(CONST_SPLITCHAR)(2))
            Next
        End If

        output.Write("document.write(d" & _treeViewId.ToString & ");")
        output.Write("</script>")

    End Sub

    Private Function GetDoclibDefaultViewUrl(ByVal dl As SPList) As String
        Dim i As Integer
        Dim vw As SPView
        For Each vw In dl.Views
            If vw.DefaultView Then
                Return vw.Url
            End If
        Next
        Return ""
    End Function

    Private Function IsMultipleDocs(ByVal strdocliblist As String) As Boolean
        If InStr(strdocliblist, ",") > 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Function IsInDoclibList(ByVal strDlTitle As String, ByVal strDocLibList As String) As Boolean
        If InStr(strDocLibList, ",") = 0 Then
            Return strDlTitle.Trim.ToLower = strDocLibList.Trim.ToLower
        Else
            Dim arrDoclibs() As String = strDocLibList.Split(",")
            Dim i As Integer
            For i = 0 To arrDoclibs.Length - 1
                If strDlTitle.Trim.ToLower = arrDoclibs(i).Trim.ToLower Then
                    Return True
                End If
            Next
            Return False
        End If
    End Function

    ' See API.html document for dtree library.  The only property
    ' Used in DLTV is the one to determine whether lines between nodes will
    ' be used.
    Private Sub SetTreeProperties(ByVal output As System.Web.UI.HtmlTextWriter)
        output.Write("d" & _treeViewId.ToString & ".config.useLines = " & IIf(_useLines, "true", "false") & ";")
    End Sub

    '*******************************************************************
    ' Purpose:  Iterate through folders, displaying folder name and
    '           any files within the folder.
    '*******************************************************************
    ' Notes:    
    '*******************************************************************
    ' Mods:     8/12/05: M.Gerow
    '           Initial release.
    '*******************************************************************
    Private Function ShowSortedFolders(ByVal fldrCol As SPFolderCollection, ByVal lvl As Integer, ByVal thisNodeId As Integer, ByVal output As System.Web.UI.HtmlTextWriter, ByVal colOutput As Collection)
        Dim arrFldrSorted() As String
        Dim i As Integer
        Dim j As Integer

        Try
            For i = 0 To fldrCol.Count - 1
                ReDim Preserve arrFldrSorted(i)
                arrFldrSorted(i) = fldrCol(i).Name & CONST_SPLITCHAR & i
            Next
            Array.Sort(arrFldrSorted)
            For i = 0 To arrFldrSorted.Length - 1
                j = arrFldrSorted(i).Split(CONST_SPLITCHAR)(1)
                'Don't include forms library
                If fldrCol(j).Name.ToLower <> "forms" Or lvl <> 1 Then
                    ShowFolderFiles(fldrCol(j), lvl, output, thisNodeId, colOutput)
                End If
            Next
        Catch ex As Exception
        End Try

    End Function

    '*******************************************************************
    ' Purpose:  Sort the files to an array and display
    '*******************************************************************
    ' Notes:    
    '*******************************************************************
    ' Mods:     8/12/05: M.Gerow
    '           Initial release.
    '
    '*******************************************************************
    Private Function ShowSortedFiles(ByVal fldr As SPFolder, ByVal thisNodeId As Integer, ByVal output As System.Web.UI.HtmlTextWriter, ByVal colOutput As Collection)
        Dim arrFlSorted() As String
        Dim i As Integer
        Dim j As Integer

        If _includeFiles Then

            For i = 0 To fldr.Files.Count - 1

                If fldr.Files(i).TimeLastModified >= Now.AddDays(-_daysBack2Include) Then

                    ReDim Preserve arrFlSorted(i)
                    If Order = EnumSortField.Name Then
                        arrFlSorted(i) = Replace(fldr.Files(i).Name, CONST_SPLITCHAR, CONST_REPLCHAR) & CONST_SPLITCHAR & i
                    ElseIf Order = EnumSortField.Title Then
                        arrFlSorted(i) = Replace(fldr.Files(i).Title, CONST_SPLITCHAR, CONST_REPLCHAR) & CONST_SPLITCHAR & i
                    ElseIf Order = EnumSortField.Sequence Then
                        Try
                            arrFlSorted(i) = fldr.Files(i).Item("Sequence") & CONST_SPLITCHAR & i
                        Catch
                            'If Sequence field doesn't exist, drop back to name sort.
                            arrFlSorted(i) = Replace(fldr.Files(i).Name, CONST_SPLITCHAR, CONST_REPLCHAR) & CONST_SPLITCHAR & i
                        End Try

                    End If

                End If

            Next

        End If

        If _showFolders Then
            Array.Sort(arrFlSorted)
            For i = 0 To arrFlSorted.Length - 1
                j = arrFlSorted(i).Split(CONST_SPLITCHAR)(1)
                output.Write("d" & _treeViewId.ToString & ".add(" & IncrNodeId() & "," & thisNodeId & ",'" & FormatTreeNode(fldr.Files(j).Name, fldr.Files(j).Title, _maxLinkWidth, fldr.Files(j).TimeLastModified.ToShortDateString) & "','" & fldr.Files(j).Url & "','','_self','_layouts/images/" & fldr.Files(j).IconUrl & "');")
            Next
        Else
            'If not showing folders, delay writing out until all files gathered, then sort all together.
            For j = 0 To arrFlSorted.Length - 1
                AddOutput(arrFlSorted(j).Split(CONST_SPLITCHAR)(0), "d" & _treeViewId.ToString & ".add(" & IncrNodeId() & "," & thisNodeId & ",'" & FormatTreeNode(fldr.Files(j).Name, fldr.Files(j).Title, _maxLinkWidth, fldr.Files(j).TimeLastModified.ToShortDateString) & "','" & fldr.Files(j).Url & "','','_self','_layouts/images/" & fldr.Files(j).IconUrl & "');", j, colOutput)
            Next
        End If

    End Function

    '*******************************************************************
    ' Purpose:  Format the link to display in treeview.
    '*******************************************************************
    ' Notes:    
    '*******************************************************************
    ' Mods:     8/12/05: M.Gerow
    '           Initial release.
    '*******************************************************************
    Private Function FormatTreeNode(ByVal strName As String, ByVal strTitle As String, ByVal numLength As Integer, ByVal strDate As String) As String
        Try
            Select Case _nodeFormat
                Case EnumNodeFormat.NameTitle
                    Return strName & " (" & Mid(strTitle & ")", 1, numLength)
                Case EnumNodeFormat.Name
                    Return strName
                Case EnumNodeFormat.Title
                    Return IIf(strTitle > "", strTitle, strName)
                Case EnumNodeFormat.TitleName
                    Return IIf(strTitle > "", strTitle, strName) & " (" & Mid(strName & ")", 1, numLength)
                Case EnumNodeFormat.NameDate
                    Return strName & " (" & strDate & ")"
                Case EnumNodeFormat.TitleDate
                    Return IIf(strTitle > "", strTitle, strName) & " (" & strDate & ")"
            End Select
        Catch ex As Exception
            Return strName
        End Try
    End Function

    '*******************************************************************
    ' Purpose:  The dtree applet needs a unique id# for each tree node,
    '           this routine returns the next id# and increments.
    '*******************************************************************
    ' Notes:    
    '*******************************************************************
    ' Mods:     8/12/05: M.Gerow
    '           Initial release.
    '*******************************************************************
    Private Function IncrNodeId() As Integer
        _nodeId = _nodeId + 1
        Return _nodeId
    End Function

    '*******************************************************************
    ' Purpose:  Show the folder and all it's files
    '*******************************************************************
    ' Notes:    
    '*******************************************************************
    ' Mods:     8/12/05: M.Gerow
    '           Initial release.
    '*******************************************************************
    Private Sub ShowFolderFiles(ByVal fl As SPFolder, ByVal lvl As Integer, ByVal output As System.Web.UI.HtmlTextWriter, ByVal parentNodeId As Integer, ByVal colOutput As Collection)

        Dim sfl As SPFolder
        Dim fi As SPFile
        Dim thisNodeId As Integer = IIf(_showFolders, IncrNodeId(), parentNodeId)

        'Print folder name
        If _showFolders Then
            output.Write("d" & _treeViewId.ToString & ".add(" & thisNodeId & "," & parentNodeId & ",'" & fl.Name & "','" & fl.Url & "','','','_layouts/images/folder.gif','_layouts/images/folderopen.gif');")
        End If

        If _folderLocation = EnumFolderLocation.Bottom Then

            'Print out all files in this folder first
            Try
                ShowSortedFiles(fl, thisNodeId, output, colOutput)
            Catch ex0 As Exception
            End Try
            'Print all sub-folders in this folder second
            ShowSortedFolders(fl.SubFolders, lvl + 1, thisNodeId, output, colOutput)

        Else

            'Print all sub-folders in this folder first
            ShowSortedFolders(fl.SubFolders, lvl + 1, thisNodeId, output, colOutput)
            'Print out all files in this folder second
            Try
                ShowSortedFiles(fl, thisNodeId, output, colOutput)
            Catch ex0 As Exception
            End Try

        End If

    End Sub

    '*******************************************************************
    ' Purpose:  If not showing folders, all files should be found, then
    '           the list sorted as appropriate.
    '*******************************************************************
    ' Notes:    
    '*******************************************************************
    ' Mods:     8/12/05: M.Gerow
    '           Initial release.
    '*******************************************************************
    Private Sub AddOutput(ByVal strSortValue As String, ByVal strOutput As String, ByVal idx As Integer, ByVal colOutput As Collection)
        Try
            Dim str As String = strSortValue & CONST_SPLITCHAR & colOutput.Count & CONST_SPLITCHAR & strOutput
            colOutput.Add(str)
        Catch ex As Exception
        End Try
    End Sub

#End Region

End Class
