Imports System.Web.Services
Imports System.Text

' ---------------------------------------------------------------------------------------
' Purpose:  Provide authorization service for use by Base web part
' ---------------------------------------------------------------------------------------
' Date:     8/18/05
' By:       M.Gerow
' ---------------------------------------------------------------------------------------
' Assumes:  Access to Authorization class
' ---------------------------------------------------------------------------------------
' Mods:
' ---------------------------------------------------------------------------------------
<System.Web.Services.WebService(Namespace:="http://tempuri.org/AuthorizationService/Service1")> _
Public Class AuthorizationService
    Inherits System.Web.Services.WebService

#Region " Web Services Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Web Services Designer.
        InitializeComponent()

        'Add your own initialization code after the InitializeComponent() call

    End Sub

    'Required by the Web Services Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Web Services Designer
    'It can be modified using the Web Services Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container
    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        'CODEGEN: This procedure is required by the Web Services Designer
        'Do not modify it using the code editor.
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

#End Region

    ' ---------------------------------------------------------------------------------------
    ' Purpose:  Return a True/False value indicating whether the specified user is a
    '           member of one of the specified AD groups.
    ' ---------------------------------------------------------------------------------------
    ' Date:     8/18/05
    ' By:       M.Gerow
    ' ---------------------------------------------------------------------------------------
    ' Assumes:  1) parameter 'loginName' is either in form userid -or- domain\userid
    '           2) service is running under an account that has the rights to query AD 
    ' ---------------------------------------------------------------------------------------
    ' Calls:    Authorization class library found in Authorization.vb
    ' ---------------------------------------------------------------------------------------
    ' Mods:
    ' ---------------------------------------------------------------------------------------
    <WebMethod()> _
   Public Function IsUserInGroupList(ByVal loginName As String, ByVal wpADGroups As String) As Boolean
        Dim delimStr As String = ",.:=;"
        Dim delimiter() As Char = delimStr.ToCharArray()
        Dim arrWpADGroups() As String = wpADGroups.Split(delimiter)
        Dim ds As New DataSet
        Dim dr As DataRow
        Dim i As Integer

        ds = GetUserADGroups(loginName)
        For Each dr In ds.Tables(0).Rows
            For i = 0 To arrWpADGroups.Length - 1
                If dr(0).ToString.ToLower.Trim = arrWpADGroups(i).ToLower.Trim Then
                    Return True
                End If
            Next
        Next
        Return False

    End Function

    ' ---------------------------------------------------------------------------------------
    ' Purpose:  Return a dataset listing all Active Directory groups a user belongs
    ' ---------------------------------------------------------------------------------------
    ' Date:     8/18/05
    ' By:       M.Gerow
    ' ---------------------------------------------------------------------------------------
    ' Assumes:  1) parameter 'loginName' is either in form userid -or- domain\userid
    '           2) service is running under an account that has the rights to query AD 
    ' ---------------------------------------------------------------------------------------
    ' Calls:    Authorization class library found in Authorization.vb
    ' ---------------------------------------------------------------------------------------
    ' Mods:
    ' ---------------------------------------------------------------------------------------
    <WebMethod()> _
    Public Function GetUserADGroups(ByVal loginName As String) As DataSet
        Dim oAuthorization As New Authorization
        Dim ds As DataSet = New DataSet
        Dim dr As DataRow
        ds.DataSetName = "GetUserADGroups"
        ds.Clear()

        ' The table 'ADGroups' is the primary output of this service.  It contains a list of the
        ' AD groups the loginName is a member of.
        Dim dt As DataTable = New DataTable
        dt.TableName = "ADGroups"
        dt.Columns.Add("ADGroup")
        ds.Tables.Add(dt)

        ' The 'RetCode' table contains information indicating whether an error occured, or
        ' if the user was found or not.  This data is for use by the calling webpart so
        ' appropriate processing or error handling can take place.
        Dim dt2 As DataTable = New DataTable
        dt2.TableName = "RetCode"
        dt2.Columns.Add("RetCode")
        dt2.Columns.Add("RetMsg")
        ds.Tables.Add(dt2)

        Try

            If oAuthorization.IsUserInAD(loginName, ds) Then
                dr = dt2.NewRow()
                dr(0) = "0"
                dr(1) = "User found."
                dt2.Rows.Add(dr)

            Else
                dr = dt2.NewRow()
                dr(0) = "1"
                dr(1) = "User not found."
                dt2.Rows.Add(dr)

            End If

        Catch ex As Exception

            dr = dt2.NewRow()
            dr(0) = "2"
            dr(1) = "Error: " + ex.Message
            dt2.Rows.Add(dr)

        End Try

        Return ds

    End Function

End Class
