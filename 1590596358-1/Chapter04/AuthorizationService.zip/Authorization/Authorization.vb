Imports System.DirectoryServices

' ---------------------------------------------------------------------------------------
' Purpose:  Provide authorization routines for use by Authorization service
' ---------------------------------------------------------------------------------------
' Date:     8/18/05
' By:       M.Gerow
' ---------------------------------------------------------------------------------------
' Assumes:  Access to Active Directory
' ---------------------------------------------------------------------------------------
' Mods:
' ---------------------------------------------------------------------------------------
Public Class Authorization

    ' ---------------------------------------------------------------------------------------
    ' Purpose:  Check to see if the domain\user specified in the 'loginName' parameter
    '           exists in Active Directory, if not return False, otherwise call the 
    '           getGroups() method to fill the 'ds' dataset parameter with all AD groups 
    '           specified user is a member of.
    ' ---------------------------------------------------------------------------------------
    ' Date:     8/18/05
    ' By:       M.Gerow
    ' ---------------------------------------------------------------------------------------
    ' Assumes:  parameter 'loginName' is either in form userid -or- domain\userid
    ' ---------------------------------------------------------------------------------------
    ' Mods:
    ' ---------------------------------------------------------------------------------------
    Public Function IsUserInAD(ByVal loginName As String, ByVal ds As DataSet) As Boolean
        Dim userName As String = GetUserAlias(loginName)
        Dim search As DirectorySearcher = New DirectorySearcher
        search.Filter = String.Format("(SAMAccountName={0})", userName)
        search.PropertiesToLoad.Add("cn")
        search.PropertiesToLoad.Add("memberOf")
        Dim result As SearchResult = search.FindOne()

        If result Is Nothing Then
            Return False
        Else
            getGroups(result, ds)
            Return True
        End If

    End Function

    ' ---------------------------------------------------------------------------------------
    ' Purpose:  Iterate through the "memberOf" list for the given user, adding a row
    '           to the dataset for each.
    ' ---------------------------------------------------------------------------------------
    ' Date:     8/18/05
    ' By:       M.Gerow
    ' ---------------------------------------------------------------------------------------
    ' Assumes:  parameter 'loginName' is either in form userid -or- domain\userid
    ' ---------------------------------------------------------------------------------------
    ' Mods:
    ' ---------------------------------------------------------------------------------------
    Private Function getGroups(ByVal result As SearchResult, ByVal ds As DataSet) As String
        Dim i As Integer
        Dim s As String = ""
        Dim delimStr As String = ",.:="
        Dim delimiter() As Char = delimStr.ToCharArray()
        Dim dr As DataRow

        For i = 0 To result.Properties("memberOf").Count - 1
            dr = ds.Tables(0).NewRow()
            dr(0) = result.Properties("memberOf")(i).ToString().Split(delimiter)(1)
            ds.Tables(0).Rows.Add(dr)
            s += ";" & dr(0)
        Next
        Return s.Substring(1)

    End Function

    ' ---------------------------------------------------------------------------------------
    ' Purpose:  Return the user alias portion of a domain/userid string
    ' ---------------------------------------------------------------------------------------
    ' Date:     8/18/05
    ' By:       M.Gerow
    ' ---------------------------------------------------------------------------------------
    ' Assumes:  parameter 'loginName' is either in form userid -or- domain\userid
    ' ---------------------------------------------------------------------------------------
    ' Mods:
    ' ---------------------------------------------------------------------------------------
    Private Function GetUserAlias(ByVal loginName As String) As String
        Dim arrUserLogin() As String = loginName.Split("\")
        Return arrUserLogin(arrUserLogin.Length - 1)
    End Function

End Class
