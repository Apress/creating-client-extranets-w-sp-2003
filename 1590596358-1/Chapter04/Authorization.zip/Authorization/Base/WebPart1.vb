Imports System
Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Xml.Serialization
Imports Microsoft.SharePoint
Imports Microsoft.SharePoint.Utilities
Imports Microsoft.SharePoint.WebPartPages

' ---------------------------------------------------------------------------------------
' Purpose:  Provide foundation for webpart targeting
' ---------------------------------------------------------------------------------------
' Date:     8/23/05
' By:       M.Gerow
' ---------------------------------------------------------------------------------------
' Assumes:  Access to Authorization web service
' ---------------------------------------------------------------------------------------
' Mods:
' ---------------------------------------------------------------------------------------
<DefaultProperty("Text"), ToolboxData("<{0}:WebPart1 runat=server></{0}:WebPart1>"), XmlRoot(Namespace:="Base")> _
Public Class WebPart1
    Inherits Microsoft.SharePoint.WebPartPages.WebPart

    Private Const _defaultText As String = ""

    Dim _text As String = _defaultText
    Dim _runAsUser As String = ""
    Dim _debug As Boolean = True
    Dim _partOrder As Integer = 1
    Dim _canAccess As Boolean = True

    ' AD Groups which are allowed to view this web part
    <Browsable(True), Category("Base"), DefaultValue(_defaultText), WebPartStorage(Storage.Personal), FriendlyName("AD Groups"), Description("AD Groups with access to this webpart.")> _
    Property ADGroups() As String
        Get
            Return _text
        End Get

        Set(ByVal Value As String)
            _text = Value
        End Set
    End Property

    ' Used to override current user with a specific AD account for authorization
    <Browsable(True), Category("Base"), DefaultValue(_defaultText), WebPartStorage(Storage.Personal), FriendlyName("Run as user"), Description("If entered, webpart will impersonate this user")> _
    Property RunAsUser() As String
        Get
            Return _runAsUser
        End Get

        Set(ByVal Value As String)
            _runAsUser = Value
        End Set
    End Property

    ' Flag to indicate whether debug information should be displayed
    <Browsable(True), Category("Base"), DefaultValue(True), WebPartStorage(Storage.Personal), FriendlyName("Debug?"), Description("Display debugging text.")> _
    Property Debug() As Boolean
        Get
            Return _debug
        End Get

        Set(ByVal Value As Boolean)
            _debug = Value
        End Set
    End Property

    ' Since hiding webpart will set it's order to 99, need a property to store
    ' desired part order when making it visible again.
    <Browsable(True), Category("Base"), DefaultValue(99), WebPartStorage(Storage.Personal), FriendlyName("Part Order"), Description("Part order - overrides WebPart.PartOrder")> _
   Property BasePartOrder() As Integer
        Get
            If _partOrder = 99 Then
                Return MyBase.PartOrder
            Else
                Return _partOrder
            End If
        End Get

        Set(ByVal Value As Integer)
            _partOrder = Value
        End Set
    End Property

    ' Indicates whether web part should be visible.
    <Browsable(False), Category("Base"), DefaultValue(False), WebPartStorage(Storage.Personal), FriendlyName("Can user access this webpart"), Description("")> _
   Property CanAccess() As Boolean
        Get
            Return _canAccess
        End Get

        Set(ByVal Value As Boolean)
            _canAccess = Value
        End Set
    End Property

    ' ---------------------------------------------------------------------------------------
    ' Purpose:  Show/hide the web part based on the user's authorization
    ' ---------------------------------------------------------------------------------------
    ' Date:     8/23/05
    ' By:       M.Gerow
    ' ---------------------------------------------------------------------------------------
    ' Assumes:  Access to Authorization web service
    ' ---------------------------------------------------------------------------------------
    ' Mods:
    ' ---------------------------------------------------------------------------------------
    Public Overridable Sub MyPreRender(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles MyBase.PreRender
        Dim oAuthorization As Authorization.AuthorizationService = New Authorization.AuthorizationService
        oAuthorization.Credentials = System.Net.CredentialCache.DefaultCredentials
        Dim usr As String = IIf(RunAsUser > "", RunAsUser, context.Current.User.Identity.Name)

        ' If no AD groups have been specified, anyone can see this web part.
        If ADGroups > "" Then
            CanAccess = oAuthorization.IsUserInGroupList(usr, ADGroups)
        Else
            CanAccess = True
        End If

        'If user can't access, hide the webpart unless Debug flag set to true.
        If Debug Or CanAccess Then
            FrameType = FrameType.Default
            PartOrder = BasePartOrder

        Else
            FrameType = FrameType.None
            PartOrder = 99

        End If

    End Sub

    ' ---------------------------------------------------------------------------------------
    ' Purpose:  Render the HTML output for the web part
    ' ---------------------------------------------------------------------------------------
    ' Date:     8/18/05
    ' By:       M.Gerow
    ' ---------------------------------------------------------------------------------------
    ' Assumes:  
    ' ---------------------------------------------------------------------------------------
    ' Mods:
    ' ---------------------------------------------------------------------------------------    
    Protected Overrides Sub RenderWebPart(ByVal output As System.Web.UI.HtmlTextWriter)

        Try
            If Debug Then
                ShowDebugText(output)
            End If
        Catch ex As Exception
            output.Write("<font color=red>Error=<b>" & ex.Message & "</b></font><br>")
        End Try

    End Sub

    ' ---------------------------------------------------------------------------------------
    ' Purpose:  Display some useful information about the web part for debugging purposes
    ' ---------------------------------------------------------------------------------------
    ' Date:     8/18/05
    ' By:       M.Gerow
    ' ---------------------------------------------------------------------------------------
    ' Assumes:  Access to Active Directory
    ' ---------------------------------------------------------------------------------------
    ' Mods:
    ' ---------------------------------------------------------------------------------------
    Protected Sub ShowDebugText(ByVal output As System.Web.UI.HtmlTextWriter)

        Try
            Dim usr As String = IIf(RunAsUser > "", RunAsUser, context.Current.User.Identity.Name)

            'Standard base variables.
            output.Write("<b><u>Base Variables</u></b><br>")
            output.Write("AD groups that can access this webpart = <b>" & ADGroups & "</b><br>")
            output.Write("Run as user = <b>" & usr & "</b><br>")
            output.Write("AD groups that current user is a member of = <b>" & GetUserADGroups(usr) & "</b><br>")
            output.Write("User can access this webpart=<b>" & IIf(CanAccess, "Yes", "No") & "</b><br>")

        Catch ex As Exception
            output.Write("<font color=red>Error=<b>" & ex.Message & "</b></font><br>")

        End Try

    End Sub

    ' ---------------------------------------------------------------------------------------
    ' Purpose:  Convert the DataTable of user AD groups returned by Authorization web
    '           service into a string that can be displayed on the web part page.
    ' ---------------------------------------------------------------------------------------
    ' Date:     8/18/05
    ' By:       M.Gerow
    ' ---------------------------------------------------------------------------------------
    ' Assumes:  Access to Authorization web service
    ' ---------------------------------------------------------------------------------------
    ' Mods:
    ' ---------------------------------------------------------------------------------------   
    Private Function GetUserADGroups(ByVal usr As String) As String
        Try
            Dim oAuthorization As Authorization.AuthorizationService = New Authorization.AuthorizationService
            Dim ds As New DataSet
            Dim str As String = ""
            Dim dr As DataRow
            oAuthorization.Credentials = System.Net.CredentialCache.DefaultCredentials
            ds = oAuthorization.GetUserADGroups(usr)
            For Each dr In ds.Tables(0).Rows
                str = str & ";" & dr(0)
            Next
            If str.Length > 0 Then
                Return str.Substring(1)
            Else
                Return ""
            End If
        Catch ex As Exception
            Return "<font color=red>" & ex.Message & "</font>"
        End Try
    End Function

End Class
