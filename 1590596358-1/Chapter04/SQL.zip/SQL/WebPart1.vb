Imports System
Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Xml.Serialization
Imports Microsoft.SharePoint
Imports Microsoft.SharePoint.Utilities
Imports Microsoft.SharePoint.WebPartPages

'Description for WebPart1.
<DefaultProperty("Text"), ToolboxData("<{0}:WebPart1 runat=server></{0}:WebPart1>"), XmlRoot(Namespace:="SQL")> _
Public Class WebPart1
    Inherits Base.WebPart1

    Private Const _defaultText As String = ""

    Dim _connectionString As String = ""
    Dim _connectionKey As String = ""
    Dim _query As String = ""
    Dim _formatUsing As enumFormatUsing = enumFormatUsing.DataGrid
    Dim _xsltPath As String = ""

    Public Enum enumFormatUsing
        DataGrid = 1
        XSLT = 2
    End Enum

    <Browsable(True), Category("SQL"), DefaultValue(_defaultText), WebPartStorage(Storage.Personal), FriendlyName("Connection String"), Description("SQL connection string")> _
    Property ConnectionString() As String
        Get
            Return _connectionString
        End Get

        Set(ByVal Value As String)
            _connectionString = Value
        End Set
    End Property

    <Browsable(True), Category("SQL"), DefaultValue(_defaultText), WebPartStorage(Storage.Personal), FriendlyName("Connection Key in Web.config"), Description("Refers to a appSettings key in web.config that contains the connections string")> _
    Property ConnectionKey() As String
        Get
            Return _connectionKey
        End Get

        Set(ByVal Value As String)
            _connectionKey = Value
        End Set
    End Property

    <Browsable(True), Category("SQL"), DefaultValue(_defaultText), WebPartStorage(Storage.Personal), FriendlyName("SQL Query"), Description("Text Property")> _
    Property Query() As String
        Get
            Return _query
        End Get

        Set(ByVal Value As String)
            _query = Value
        End Set
    End Property

    <Browsable(True), Category("SQL"), DefaultValue(enumFormatUsing.DataGrid), WebPartStorage(Storage.Personal), FriendlyName("Format output using"), Description("How to format the output from the data source.")> _
    Property FormatUsing() As enumFormatUsing
        Get
            Return _formatUsing
        End Get

        Set(ByVal Value As enumFormatUsing)
            _formatUsing = Value
        End Set
    End Property

    <Browsable(True), Category("SQL"), DefaultValue(""), WebPartStorage(Storage.Personal), FriendlyName("XSLT path"), Description("Path to XSLT to format data with.")> _
    Property XSLTPath() As String
        Get
            Return _xsltPath
        End Get

        Set(ByVal Value As String)
            _xsltPath = Value
        End Set
    End Property

    'Render this Web Part to the output parameter specified.
    Protected Overrides Sub RenderWebPart(ByVal output As System.Web.UI.HtmlTextWriter)
        Try

            If Debug Then
                MyBase.ShowDebugText(output)
                output.Write("<hr>")
                output.Write("<b><u>Universal variables</u></b><br>")
                output.Write("Connection string = <b>" & ConnectionString & "</b><br>")
                output.Write("Connection key = <b>" & ConnectionKey & "</b><br>")
                output.Write("SQL query (before token replacement) = <b>" & Query & "</b><br>")
                output.Write("SQL query (after token replacement) = <b>" & _query & "</b><br>")
                output.Write("Format output using = <b>" & FormatUsing.ToString & "</b><br>")
                output.Write("XSLT path = <b>" & XSLTPath & "</b><br>")
                output.Write("<hr>")
            End If
            If CanAccess() Then
                RenderSourceData(ReadSourceData(output), output)
            End If
        Catch ex As Exception
            output.Write("<font color=red>" & ex.Message & "</font><br>")
        End Try
    End Sub

    Private Function ReadSourceData(ByVal output As System.Web.UI.HtmlTextWriter) As DataSet
        Try
            Dim conString As String
            If ConnectionKey > "" Then
                conString = Configuration.ConfigurationSettings.AppSettings.Item(ConnectionKey)
            Else
                conString = ConnectionString
            End If
            Dim sa As New SqlClient.SqlDataAdapter(_query, conString)
            Dim ds As New DataSet
            sa.Fill(ds)
            Return ds
        Catch ex As Exception
            output.Write("<font color=red>" & ex.Message & "</font><br>")
        End Try
    End Function

    Private Function RenderSourceData(ByVal ds As DataSet, ByVal output As System.Web.UI.HtmlTextWriter)
        Try
            If FormatUsing = enumFormatUsing.DataGrid Then
                Dim dg As New DataGrid
                dg.DataSource = ds
                dg.DataBind()
                dg.RenderControl(output)
            Else
                Dim xsl As New System.Web.UI.WebControls.Xml
                xsl.DocumentContent = CType(ds.GetXml, String)
                xsl.TransformSource = XSLTPath
                xsl.RenderControl(output)
            End If
        Catch ex As Exception
            output.Write("<font color=red>" & ex.Message & "</font><br>")
        End Try
    End Function

End Class
