Imports System
Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Xml.Serialization
Imports Microsoft.SharePoint
Imports Microsoft.SharePoint.Utilities
Imports Microsoft.SharePoint.WebPartPages

'Description for WebPart1.
<DefaultProperty("Text"), ToolboxData("<{0}:WebPart1 runat=server></{0}:WebPart1>"), XmlRoot(Namespace:="XML")> _
Public Class WebPart1
    Inherits Base.WebPart1

    Private Const _defaultText As String = ""

    Dim _text As String = _defaultText
    Dim _XmlSource As String = ""
    Dim _XslSource As String = ""
    Dim _iaContactId As String = ""

    <Browsable(True), Category("FW XML"), DefaultValue(_defaultText), WebPartStorage(Storage.Personal), FriendlyName("XML Source Url"), Description("Url where XML document can be read")> _
    Property XMLSource() As String
        Get
            Try
                Return _XmlSource
            Catch ex As Exception
                'Handel error.
            End Try
        End Get

        Set(ByVal Value As String)
            _XmlSource = Value
        End Set
    End Property

    <Browsable(True), Category("FW XML"), DefaultValue(_defaultText), WebPartStorage(Storage.Personal), FriendlyName("XSL Source Url"), Description("Must be relative to root of this site.")> _
    Property XSLSource() As String
        Get
            Return _XslSource
        End Get

        Set(ByVal Value As String)
            _XslSource = Value
        End Set
    End Property

    ' -------------------------------------------------------------------------------------
    ' Purpose:  Render this Web Part to the output parameter specified.
    ' By:       M.Gerow
    ' Date:     8/15/05
    ' -------------------------------------------------------------------------------------
    ' Modifications:
    '           9/12/05, M.Gerow
    '           Replaced GetUrlAsString with XmlDoc.Load() call to resolve problem with 
    '           LexisNexis source.
    ' -------------------------------------------------------------------------------------
    Protected Overrides Sub RenderWebPart(ByVal output As System.Web.UI.HtmlTextWriter)

        Try
            If Debug Then
                ShowDebugText(output)
                output.Write("<br>XML Source=<b>" & XMLSource & "</b>")
                output.Write("<br>XSL Source=<b>" & XSLSource & "</b>")
                output.Write("<hr>")
            End If
            If CanAccess() Then
                Dim xml As New System.Web.UI.WebControls.Xml
                Dim xmlDoc As New System.Xml.XmlDocument
                xmlDoc.Load(_XmlSource)
                xml.Document = xmlDoc
                xml.RenderControl(output)
            End If
        Catch ex As Exception
            output.Write("<font color=red>" & ex.Message & "</font>")
        End Try

    End Sub

    Private Function GetUrlAsString(ByVal strUrl As String) As String
        Dim wReq As System.Net.WebRequest
        wReq = System.Net.WebRequest.Create(strUrl)
        wReq.Credentials = Net.CredentialCache.DefaultCredentials
        wReq.Method = "GET"

        ' Return the response. 
        Dim wResp As System.Net.WebResponse = wReq.GetResponse()

        ' Read the response stream into a string
        Dim respStream As System.IO.Stream = wResp.GetResponseStream
        Dim respStreamReader As New System.IO.StreamReader(respStream, System.Text.Encoding.ASCII)
        Dim strHTML As String = respStreamReader.ReadToEnd
        Return strHTML

    End Function

End Class
