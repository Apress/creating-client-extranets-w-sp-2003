Imports System.IO
Imports System.Configuration
Imports System.Web

Module Module1

    Sub Main(ByVal args() As String)
        Dim dsRequests As New DataSet
        Dim drRequest As DataRow
        dsRequests.ReadXml("c:\CacheLoaderConfig.xml")

        'Get a list of all customers
        Dim strConCustomers As String = "user id=Pubs_Test;data source=spsdev; initial catalog=Northwind"
        Dim strQryCustomers As String = "select CustomerID from Customers order by CustomerID"
        Dim saCustomers As New SqlClient.SqlDataAdapter(strQryCustomers, strConCustomers)
        Dim dsCustomers As New DataSet
        Dim drCustomer As DataRow
        saCustomers.Fill(dsCustomers)

        'Loop through each Request, and write one XML document for each customer
        Dim dsResultSet As New DataSet
        Dim saResultSet As New SqlClient.SqlDataAdapter
        Dim strConResultSet As String
        Dim strQryResultSet As String
        Dim strOutputName As String

        'Process each cache loader request
        For Each drRequest In dsRequests.Tables(0).Rows

            'Process for each customer
            For Each drCustomer In dsCustomers.Tables(0).Rows
                strQryResultSet = Replace(LCase(drRequest("SQLCommand")), "[customerid]", drCustomer("CustomerID"))
                strConResultSet = drRequest("SQLConnection")
                dsResultSet = New DataSet
                saResultSet = New SqlClient.SqlDataAdapter(strQryResultSet, strConResultSet)
                saResultSet.Fill(dsResultSet)
                strOutputName = "c:\XMLCache\" & drRequest("OutputName") & "_" & drCustomer("CustomerID") & ".XML"
                dsResultSet.WriteXml(strOutputName)
                Console.WriteLine(strOutputName & " written.")
            Next

        Next

        Console.WriteLine("")
        Console.WriteLine("Processing complete.")
        Console.ReadLine()

    End Sub

End Module
