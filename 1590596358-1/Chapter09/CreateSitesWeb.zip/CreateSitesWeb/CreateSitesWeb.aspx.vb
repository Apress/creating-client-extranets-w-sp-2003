Imports System.Configuration
Imports Microsoft.SharePoint
Imports Microsoft.SharePoint.WebControls
Imports System.Web.UI
Imports System.Xml
Imports Microsoft.SharePoint.Security

Public Class WebForm1
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lblCustomerID As System.Web.UI.WebControls.Label
    Protected WithEvents txtCustomerID As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblSiteDescrip As System.Web.UI.WebControls.Label
    Protected WithEvents txtSiteDescrip As System.Web.UI.WebControls.TextBox
    Protected WithEvents cmdCreateSite As System.Web.UI.WebControls.Button
    Protected WithEvents lblOutput As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    'Site definition variables
    Private strParentSite As String
    Private strSiteName As String
    Private strSiteTitle As String
    Private strSiteDescrip As String
    Private strTemplateName As String = "NEWTEMPLATE"
    Private uInt32LocId As UInt32 = System.Convert.ToUInt32(1033)
    Private strNorthwindConnectionString As String = "user id=Northwind_test_user;data source=(local);persist security info=False;initial catalog=Northwind"

    'Content editor web part variables(s)
    Private strWelcomeMsg As String

    'SQL web part variables(s)
    Private strCustomerID As String

    'Get handle to new site
    Dim web As SPWeb = SPControl.GetContextWeb(Context)

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'Default customer ID, site description to site name.
        Response.Write(web.WebTemplate)
        If Not IsPostBack Then
            txtCustomerID.Text = web.Name
            txtSiteDescrip.Text = "New site for " & web.Name
        End If

    End Sub

    Private Sub cmdCreateSite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCreateSite.Click

        Try
            'Site name is same as customer id
            strCustomerID = txtCustomerID.Text

            'Provide a friendly description
            strSiteDescrip = txtSiteDescrip.Text

            'Set the site title to the customer name in the customers table
            Dim da As New SqlClient.SqlDataAdapter(String.Format("select * from customers where CustomerId='{0}'", strCustomerID), strNorthwindConnectionString)
            Dim ds As New DataSet
            Dim dr As DataRow
            da.Fill(ds)
            dr = ds.Tables(0).Rows(0)
            strSiteTitle = dr("CompanyName")
            strWelcomeMsg = String.Format("<br/>Welcome <strong>{0}</strong>.  The contact information we have on record for you is:<br/><br/><strong>{1}</strong><br/>{2}<br/>{3}, {4}  {5}<br/>{6}<br/>{7}", dr("ContactName"), dr("ContactTitle"), dr("Address"), dr("City"), dr("Region"), dr("PostalCode"), dr("Country"), dr("Phone"))

        Catch ex As Exception
            lblOutput.Text = lblOutput.Text & ("Error: one or more parameters were incorrect.")
            lblOutput.Text = lblOutput.Text & "<BR/>"
            Exit Sub
        End Try

        Try

            'Set the title of site = to customer id.
            web.AllowUnsafeUpdates = True
            web.Title = strSiteTitle
            web.Description = strSiteDescrip
            web.Update()

            'Get handle to web parts default.aspx page, and iterate through web parts 
            Dim webParts As SPWebPartCollection = web.GetWebPartCollection(web.Url & "/default.aspx", Microsoft.SharePoint.WebPartPages.Storage.Shared)

            'Enable updates to web part collection.
            webParts.Web.AllowUnsafeUpdates = True

            'Get handle to collection of web parts on default page.
            Dim wp As WebPartPages.WebPart
            Dim i As Integer

            'Skip through web parts, deleting all except TreeViews.
            For i = webParts.Count - 1 To 0 Step -1
                wp = webParts(i)
                Console.Write(wp.Title & ": " & wp.GetType.ToString)
                If wp.GetType.ToString <> "MG.WebParts.DLTV.WebPart1" Then
                    webParts.Delete(wp.StorageKey)
                End If
            Next

            'Add a "Welcome" content editor web part
            Dim ce As New WebPartPages.ContentEditorWebPart
            ' Create an XmlElement to hold the value of the Content property.
            Dim xmlDoc = New XmlDocument
            Dim xmlElement As XmlElement = xmlDoc.CreateElement("MyElement")
            xmlElement.InnerText = strWelcomeMsg
            ce.ZoneID = "Right"
            ce.PartOrder = 1
            ce.Title = String.Format("Welcome message for {0}...", strSiteTitle)
            ce.Content = xmlElement
            webParts.Add(ce)

            'Add a SQL web part to display client orders
            Dim sql As New MG.WebParts.SQL.WebPart1
            sql.ConnectionString = strNorthwindConnectionString
            sql.Query = "SELECT TOP 10 dbo.Customers.CompanyName, dbo.Orders.OrderID, dbo.Products.ProductName, " & _
                "dbo.[Order Details].UnitPrice, dbo.[Order Details].Quantity, dbo.Orders.ShippedDate, " & _
                "dbo.[Order Details].Quantity * dbo.[Order Details].UnitPrice AS ExtPrice " & _
                "FROM dbo.Customers INNER JOIN dbo.Orders " & _
                "ON dbo.Customers.CustomerID = dbo.Orders.CustomerID " & _
                "INNER JOIN dbo.[Order Details] ON dbo.Orders.OrderID = dbo.[Order Details].OrderID " & _
                "INNER JOIN dbo.Products ON dbo.[Order Details].ProductID = dbo.Products.ProductID " & _
                "WHERE (dbo.Customers.CustomerID = N'" & strCustomerID & "') " & _
                "ORDER BY ExtPrice DESC"
            sql.XSLTPath = "XSLT/NorthwindSQL.xsl"
            sql.FormatUsing = MG.WebParts.SQL.WebPart1.enumFormatUsing.XSLT
            sql.ZoneID = "Left"
            sql.PartOrder = 2
            sql.Title = "TOP 10 Orders for: " & strSiteTitle
            webParts.Add(sql)

            'Editing the existing TreeView web part
            Dim tv As New MG.WebParts.DLTV.WebPart1
            tv = webParts(0)
            tv.Title = "Extranet documents for: " & strSiteTitle
            tv.ZoneID = "Left"
            tv.PartOrder = 1
            tv.UseLines = False
            webParts.SaveChanges(tv.StorageKey)

        Catch ex As Exception
            'Handle exception
            lblOutput.Text = lblOutput.Text & ("Error: " & ex.Message)
            lblOutput.Text = lblOutput.Text & "<BR/>"
            Exit Sub

        End Try

        'Customizations complete, take use to site's main page.
        Response.Redirect(web.Url)

    End Sub

End Class
