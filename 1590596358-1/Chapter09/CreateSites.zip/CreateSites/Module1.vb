Imports System.Configuration
Imports Microsoft.SharePoint
Imports System.Web.UI
Imports System.Xml

Module CreateSite

    'Site definition variables
    Private strParentSite As String = "http://localhost/sites/AllClients/"
    Private strSiteName As String
    Private strSiteTitle As String
    Private strSiteDescrip As String
    Private strTemplateName As String = "NEWTEMPLATE"
    Private uInt32LocId As UInt32 = System.Convert.ToUInt32(1033)
    Private strNorthwindConnectionString As String = "user id=Northwind_test_user;data source=(local);persist security info=False;initial catalog=Northwind"

    'Content editor web part variables(s)
    Private strWelcomeMsg As String

    'SQL web part variables(s)
    Private strCustomerID As String

    Sub Main(ByVal args() As String)

        Try
            'Site name is same as customer id
            strSiteName = args(0)
            strCustomerID = args(0)

            'Provide a friendly description
            strSiteDescrip = args(1)

            'Set the site title to the customer name in the customers table
            Dim da As New SqlClient.SqlDataAdapter(String.Format("select * from customers where CustomerId='{0}'", strCustomerID), strNorthwindConnectionString)
            Dim ds As New DataSet
            Dim dr As DataRow
            da.Fill(ds)
            dr = ds.Tables(0).Rows(0)
            strSiteTitle = dr("CompanyName")
            strWelcomeMsg = String.Format("<br/>Welcome <strong>{0}</strong>.  The contact information we have on record for you is:<br/><br/><strong>{1}</strong><br/>{2}<br/>{3}, {4}  {5}<br/>{6}<br/>{7}", dr("ContactName"), dr("ContactTitle"), dr("Address"), dr("City"), dr("Region"), dr("PostalCode"), dr("Country"), dr("Phone"))

        Catch ex As Exception
            Console.WriteLine("Error: one or more parameters were incorrect.")
            Console.WriteLine()
            Console.WriteLine("Syntax:")
            Console.WriteLine()
            Console.WriteLine("CREATESITES <customerid> <site description>")
            Console.WriteLine()
            Exit Sub
        End Try

        Try
            'Get handle to parent site of new site
            Dim site As New SPSite(strParentSite & "/default.aspx")

            'Create the site
            site.AllWebs.Add(strSiteName, _
                strSiteTitle, _
                strSiteDescrip, _
                System.Convert.ToUInt32(1033), _
                strTemplateName, _
                False, _
                False)

            Console.WriteLine()
            Console.WriteLine("Site: " & strParentSite & strSiteName & " successfuly created.")

            'Get handle to web parts default.aspx page, and iterate through web parts 
            Dim strThePage As String = strParentSite & strSiteName & "/default.aspx"
            Dim web As SPWeb = site.OpenWeb(strSiteName)
            Dim webParts As SPWebPartCollection = web.GetWebPartCollection(strThePage, Microsoft.SharePoint.WebPartPages.Storage.Shared)
            Dim wp As WebPartPages.WebPart
            Dim i As Integer

            Console.WriteLine("")
            For i = webParts.Count - 1 To 0 Step -1
                wp = webParts(i)
                Console.Write(wp.Title & ": " & wp.GetType.ToString)
                If wp.GetType.ToString <> "MG.WebParts.DLTV.WebPart1" Then
                    webParts.Delete(wp.StorageKey)
                    Console.WriteLine(".... Deleted.")
                Else
                    Console.WriteLine(".... Kept.")
                End If
            Next

            'Add a "Welcome" content editor web part
            Console.WriteLine("")
            Console.Write("Adding content editor web part.")
            Dim ce As New WebPartPages.ContentEditorWebPart
            ' Create an XmlElement to hold the value of the Content property.
            Dim xmlDoc = New XmlDocument
            Dim xmlElement As XmlElement = xmlDoc.CreateElement("MyElement")
            xmlElement.InnerText = strWelcomeMsg
            ce.ZoneID = "Right"
            ce.PartOrder = 1
            ce.Title = String.Format("Welcome message for {0}...", strSiteTitle)
            ce.Content = xmlElement
            webParts.Add(ce)
            Console.WriteLine("... Added.")

            'Add a SQL web part to display client orders
            Console.WriteLine("")
            Console.Write("Adding SQL web part.")
            Dim sql As New MG.WebParts.SQL.WebPart1
            sql.ConnectionString = strNorthwindConnectionString
            sql.Query = "SELECT TOP 10 dbo.Customers.CompanyName, dbo.Orders.OrderID, dbo.Products.ProductName, " & _
                "dbo.[Order Details].UnitPrice, dbo.[Order Details].Quantity, dbo.Orders.ShippedDate, " & _
                "dbo.[Order Details].Quantity * dbo.[Order Details].UnitPrice AS ExtPrice " & _
                "FROM dbo.Customers INNER JOIN dbo.Orders " & _
                "ON dbo.Customers.CustomerID = dbo.Orders.CustomerID " & _
                "INNER JOIN dbo.[Order Details] ON dbo.Orders.OrderID = dbo.[Order Details].OrderID " & _
                "INNER JOIN dbo.Products ON dbo.[Order Details].ProductID = dbo.Products.ProductID " & _
                "WHERE (dbo.Customers.CustomerID = N'" & strCustomerID & "') " & _
                "ORDER BY ExtPrice DESC"
            sql.XSLTPath = "XSLT/NorthwindSQL.xsl"
            sql.FormatUsing = MG.WebParts.SQL.WebPart1.enumFormatUsing.XSLT
            sql.ZoneID = "Left"
            sql.PartOrder = 2
            sql.Title = "TOP 10 Orders for: " & strSiteTitle
            webParts.Add(sql)
            Console.WriteLine("... Added.")

            'Editing the existing TreeView web part
            Console.WriteLine("")
            Console.Write("Editing TreeView web part.")
            Dim tv As New MG.WebParts.DLTV.WebPart1
            tv = webParts(0)
            tv.Title = "Extranet documents for: " & strSiteTitle
            tv.ZoneID = "Left"
            tv.PartOrder = 1
            tv.UseLines = False
            webParts.SaveChanges(tv.StorageKey)
            Console.WriteLine("... Edited.")

        Catch ex As Exception
            'Handle exception
            Console.WriteLine("...Error: " & ex.Message)

        End Try
        Console.WriteLine("")

    End Sub

End Module
