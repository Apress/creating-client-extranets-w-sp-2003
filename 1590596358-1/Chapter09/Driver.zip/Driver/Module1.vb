Module Driver

    Private strSiteRequestConnectionString As String = "user id=Northwind_test_user;data source=(local);persist security info=False;initial catalog=Northwind"
    Private con As New SqlClient.SqlConnection(strSiteRequestConnectionString)
    Private sql As New SqlClient.SqlCommand
    Private da As New SqlClient.SqlDataAdapter("select * from Customers where Status='' or Status IS NULL order by CustomerID", strSiteRequestConnectionString)
    Private ds As New DataSet
    Private dr As DataRow

    Sub Main()

        da.Fill(ds)
        'Loop through SiteRequest queue, processing all requests with a 'Pending' status.
        For Each dr In ds.Tables(0).Rows
            Try
                Shell("C:\Documents and Settings\Administrator\My Documents\Visual Studio Projects\CreateSites\bin\CreateSites.exe " & dr(0) & " " & dr(1) & "", AppWinStyle.Hide, True)
                UpdateRequestStatus(dr("CustomerID"), "Complete", "")
            Catch ex As Exception
                UpdateRequestStatus(dr("CustomerID"), "Failed", ex.Message)
            End Try
        Next

    End Sub

    Private Sub UpdateRequestStatus(ByVal strCustomerID As String, ByVal strStatus As String, ByVal strNotes As String)

        'Update status to reflect fact that request(s) has/have been processed.
        con.Open()
        sql.CommandText = String.Format("Update Customers set Status='{2}', ProcessDateTime='{0}', ProcessNotes='{3}' where CustomerId='{1}'", Now, strCustomerID, strStatus, strNotes)
        sql.Connection = con
        sql.ExecuteNonQuery()
        con.Close()

    End Sub

End Module
