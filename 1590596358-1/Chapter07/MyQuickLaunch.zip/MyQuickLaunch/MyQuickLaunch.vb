Imports System.ComponentModel
Imports System.Web.UI
Imports Microsoft.SharePoint
Imports Microsoft.SharePoint.WebControls


<DefaultProperty("Text"), ToolboxData("<{0}:QL runat=server></{0}:QL>")> Public Class QL
    Inherits System.Web.UI.WebControls.WebControl

    Dim _xsltSource As String

    <Bindable(True), Category("Appearance"), DefaultValue("")> Property XSLTSource() As String
        Get
            Return _xsltSource
        End Get

        Set(ByVal Value As String)
            _xsltSource = Value
        End Set
    End Property

    Protected Overrides Sub Render(ByVal output As System.Web.UI.HtmlTextWriter)
        Dim web As SPWeb = SPControl.GetContextWeb(context)
        Dim list As SPList

        'Create a DataTable object to hold the results
        Dim dt As New DataTable("MyLists")
        Dim dr As DataRow
        dt.Columns.Add("Template")
        dt.Columns.Add("Title")
        dt.Columns.Add("Url")
        dt.Columns.Add("ImageUrl")
        dt.Columns.Add("Description")
        dt.Columns.Add("Type")

        'Only include lists that the current user is authorized to view
        web.Lists.ListsForCurrentUser = True

        'Iterate through the list items, adding to the DataTable those 
        'that are flagged as visible and to be displayed on the Quick Launch
        For Each list In web.Lists
            If list.Hidden = False And list.OnQuickLaunch = True Then
                dr = dt.NewRow
                dr("Type") = list.BaseType
                dr("Title") = list.Title
                dr("Url") = list.DefaultViewUrl
                dr("ImageUrl") = list.ImageUrl
                dr("Description") = list.Description
                dr("Template") = list.BaseTemplate
                dt.Rows.Add(dr)
            End If
        Next

        'Display the list on the page.
        Dim xml As New Web.UI.WebControls.Xml
        Dim ds As New DataSet("MyLists")
        ds.Tables.Add(dt)
        xml.DocumentContent = ds.GetXml
        xml.TransformSource = XSLTSource
        xml.RenderControl(output)

    End Sub

End Class
