Imports Microsoft.SharePoint
Imports Microsoft.SharePoint.WebControls

Public Class WebForm1
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents DropDownList1 As System.Web.UI.WebControls.DropDownList

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Not IsPostBack Then

            'Build a table to hold the results of search
            Dim dt As New DataTable("ClientSites")
            dt = GetMySites(dt)

            'Display results in the data grid.
            DataGrid1.DataSource = dt
            DataGrid1.DataBind()

            'Add list of site types to drop down list
            Dim strTemplateList As String = ""
            Dim dr As DataRow
            Dim li As ListItem
            DropDownList1.Items.Clear()
            DropDownList1.SelectedIndex = 0
            DropDownList1.AutoPostBack = True

            li = New ListItem("(All)", "%")
            DropDownList1.Items.Add(li)

            For Each dr In dt.Rows
                If InStr(strTemplateList, dr("Template")) = 0 Then
                    strTemplateList = strTemplateList & "," & dr("Template")
                    li = New ListItem(dr("Template"), dr("Template"))
                    DropDownList1.Items.Add(li)
                End If
            Next

        End If

    End Sub

    Private Function GetMySites(ByVal dt As DataTable) As DataTable

        Dim web As SPWeb = SPControl.GetContextWeb(context)
        Dim subwebs As SPWebCollection = web.GetSubwebsForCurrentUser
        Dim subweb As SPWeb
        Dim dr As DataRow

        dt.Columns.Add("Image")
        dt.Columns.Add("Name")
        dt.Columns.Add("Title")
        dt.Columns.Add("Description")
        dt.Columns.Add("Template")
        dt.Columns.Add("Type")
        dt.Columns.Add("Url")

        'Get a list of all webs (sites) the user has access to
        For Each subweb In subwebs
            dr = dt.NewRow
            dr("Image") = GetImage(subweb.WebTemplate)
            dr("Name") = subweb.Name
            dr("Title") = subweb.Title
            dr("Description") = subweb.Description
            dr("Template") = subweb.WebTemplate
            dr("Url") = subweb.Url
            dt.Rows.Add(dr)
        Next
        Return dt

    End Function

    Private Function GetImage(ByVal strTemplate As String) As String
        'Modify as needed to associate different icons with different templates.
        Return "<img src='/_layouts/images/folder.GIF' border='0' />"
    End Function

    Private Sub DropDownList1_SelectedIndexChanged(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles DropDownList1.SelectedIndexChanged
        Dim dt As New DataTable("ClientSites")
        dt = GetMySites(dt)
        Dim dv As New DataView
        dv.Table = dt
        dv.RowFilter = "Template LIKE '" & sender.selectedvalue & "'"
        DataGrid1.DataSource = dv
        DataGrid1.DataBind()
    End Sub

End Class
