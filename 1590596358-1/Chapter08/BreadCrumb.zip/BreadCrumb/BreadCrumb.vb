Imports System.ComponentModel
Imports System.Web.UI
Imports Microsoft.SharePoint
Imports System.Web

<DefaultProperty("Text"), ToolboxData("<{0}:BreadCrumb1 runat=server></{0}:BreadCrumb1>")> Public Class BreadCrumb1
    Inherits System.Web.UI.WebControls.WebControl

    Dim m_SpWeb As SPWeb

    Protected Overrides Sub Render(ByVal output As System.Web.UI.HtmlTextWriter)

        'Get the context of the current web site being displayed
        Dim objWeb As SPWeb = Microsoft.SharePoint.WebControls.SPControl.GetContextWeb(Context)
        Dim breadcrumbTrail As String = ""

        Try
            'Recursively "walk" up the site hierarchy to display a breadcrumb.
            CompileTrail(objWeb, output, breadcrumbTrail)
            output.Write("<div width='100%' class='ms-WPBody' style='' ><b>Breadcrumb server control: " + breadcrumbTrail + "</b></div><br/>")

        Catch ex As Exception
            output.Write("Error:  " + ex.Message)

        End Try

    End Sub
    Private Sub CompileTrail(ByVal objWeb As SPWeb, ByVal output As HtmlTextWriter, ByRef breadcrumbTrail As String)

        ' Set current web as we recurse
        m_SpWeb = objWeb

        If Trim(breadcrumbTrail) = "" Then
            ' If on the home page itself
            If objWeb.Url.ToString + "/default.aspx" = context.Request.Url.ToString Then
                breadcrumbTrail = objWeb.Title.ToString()   ' Do not link to itself
            Else
                breadcrumbTrail = "<b><a href=" + objWeb.Url.ToString() + ">" + objWeb.Title.ToString() + "</a></b>"
            End If
        Else
            ' Provide link
            breadcrumbTrail = "<a href=" + objWeb.Url.ToString() + ">" + objWeb.Title.ToString() + "</a> > " + breadcrumbTrail
        End If

        ' If there is a parent, go to and continue to build breadcrumb
        If (Not (objWeb.ParentWeb) Is Nothing) Then
            CompileTrail(objWeb.ParentWeb, output, breadcrumbTrail)
        End If

    End Sub

End Class
